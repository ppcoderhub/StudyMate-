# StudyMate - Real-time version

```
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000 -> Create Account -> Login.

Everything is real: SQLite database (studymate.db), every number comes from your own use.
New account starts empty. Use the "Demo fill" button on any page to type a casual student-style sample.
Dashboard refreshes every 5 seconds. Quiz/Flashcards/Chat use your latest analyzed material automatically.
