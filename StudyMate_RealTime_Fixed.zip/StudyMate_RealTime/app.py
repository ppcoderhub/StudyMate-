
from flask import Flask, render_template, request, jsonify, session, redirect, send_file
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3, re, math, os, io
from datetime import datetime, timedelta
from collections import Counter
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
import textstat

app=Flask(__name__,template_folder="frontend/templates",static_folder="frontend/static")
app.secret_key="studymate-final-year-secret"
DB="studymate.db"
UPLOAD="uploads"
os.makedirs(UPLOAD,exist_ok=True)

STOP=set("""a an the and or but is are was were to of in on for with as by from at this that these those it its be been has have had do does did can could will would should may might into about after before between during through over under than then there their them they he she his her we you your i me my our""".split())

def con():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c

def init_db():
    c=con()
    c.execute("CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,email TEXT UNIQUE,password TEXT)")
    c.execute("CREATE TABLE IF NOT EXISTS materials(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,subject TEXT,filename TEXT,content TEXT,summary TEXT,keywords TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)")
    c.execute("CREATE TABLE IF NOT EXISTS scores(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,subject TEXT,score INTEGER,total INTEGER,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)")
    c.execute("CREATE TABLE IF NOT EXISTS bookmarks(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,title TEXT,content TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)")
    c.execute("CREATE TABLE IF NOT EXISTS activity(id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER,kind TEXT,topic TEXT,detail TEXT,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)")
    c.commit(); c.close()

def log(kind,topic,detail=""):
    c=con(); c.execute("INSERT INTO activity(user_id,kind,topic,detail) VALUES(?,?,?,?)",(session["uid"],kind,topic,detail)); c.commit(); c.close()

def latest_text(t):
    if (t or "").strip(): return t
    c=con(); r=c.execute("SELECT content FROM materials WHERE user_id=? ORDER BY id DESC LIMIT 1",(session.get("uid"),)).fetchone(); c.close()
    return r["content"] if r else ""

def toks(t): return re.findall(r"[A-Za-z][A-Za-z'-]*",t.lower())
def sents(t): return [x.strip() for x in re.split(r"(?<=[.!?])\s+",t.strip()) if x.strip()]

def stem(w):
    for suf in ("ingly","edly","ing","ed","ies","es","s"):
        if len(w)>len(suf)+3 and w.endswith(suf): return w[:-len(suf)]
    return w

def lemma(w):
    return {"studies":"study","studying":"study","better":"good","cars":"car","children":"child","mice":"mouse"}.get(w,w)

def keywords(t,n=15):
    try:
        v=TfidfVectorizer(stop_words="english",ngram_range=(1,2),max_features=60)
        a=v.fit_transform([t]).toarray()[0]; names=v.get_feature_names_out()
        return [{"term":w,"score":round(float(s),3)} for w,s in sorted(zip(names,a),key=lambda z:z[1],reverse=True)[:n]]
    except: return []

def summary(t,n=6):
    ss=sents(t)
    if len(ss)<=n:return ss
    freq=Counter(w for w in toks(t) if w not in STOP)
    scored=[]
    for i,s in enumerate(ss):
        ws=toks(s); scored.append((sum(freq[x] for x in ws)/max(1,len(ws)),i,s))
    return [x[2] for x in sorted(sorted(scored,reverse=True)[:n],key=lambda z:z[1])]

def pos_simple(words):
    out=[]
    for w in words[:180]:
        tag="NN"
        if w.endswith("ing"): tag="VBG"
        elif w.endswith("ed"): tag="VBD"
        elif w.endswith("ly"): tag="RB"
        elif w.endswith(("ous","ful","ive","al")): tag="JJ"
        elif w in ("is","are","was","were","be","have","has","do","does"): tag="VB"
        out.append({"word":w,"tag":tag})
    return out

def entities(t):
    # Lightweight NER fallback: consecutive capitalized words.
    found=[]
    for m in re.finditer(r"\b(?:[A-Z][a-z]+(?:\s+|$)){1,3}",t):
        x=m.group().strip()
        if len(x)>2 and x.lower() not in STOP:
            found.append({"text":x,"type":"PROPER_NOUN"})
    seen=set(); out=[]
    for x in found:
        if x["text"] not in seen: out.append(x); seen.add(x["text"])
    return out[:30]

def analyze(t):
    raw=toks(t); clean=[x for x in raw if x not in STOP and len(x)>2]
    return {
      "tokens":raw[:250],"filtered":clean[:250],
      "stems":[stem(x) for x in clean[:180]],
      "lemmas":[lemma(x) for x in clean[:180]],
      "pos":pos_simple(raw),
      "entities":entities(t),"keywords":keywords(t),"summary":summary(t),
      "stats":{"characters":len(t),"words":len(raw),"sentences":len(sents(t)),
               "unique_words":len(set(raw)),"reading_minutes":max(1,math.ceil(len(raw)/200)),
               "reading_grade":round(textstat.flesch_kincaid_grade(t),1) if t.strip() else 0}
    }

def questions(t,n=10):
    ks=[x["term"].split()[-1] for x in keywords(t,25)]
    out=[]
    for s in sents(t):
        hit=next((k for k in ks if re.search(r"\b"+re.escape(k)+r"\b",s,re.I)),None)
        if hit:
            out.append({"question":"Fill in the blank: "+re.sub(r"\b"+re.escape(hit)+r"\b","__________",s,count=1,flags=re.I),"answer":hit})
        if len(out)>=n: break
    return out

def mcqs(t,n=8):
    qs=questions(t,n); pool=[x["term"] for x in keywords(t,30)]
    out=[]
    for q in qs:
        opts=[q["answer"]]+[x for x in pool if x.lower()!=q["answer"].lower()][:3]
        while len(opts)<4: opts.append("None of these")
        out.append({"question":q["question"],"options":opts[:4],"answer":q["answer"]})
    return out

def chunks(t): return [x.strip() for x in re.split(r"\n+|(?<=[.!?])\s+",t) if len(x.strip())>20]

def chat_answer(t,q):
    cs=chunks(t)
    if not cs:return "Please provide study material first."
    try:
        v=TfidfVectorizer(stop_words="english"); m=v.fit_transform(cs+[q])
        scores=cosine_similarity(m[-1],m[:-1])[0]; idx=scores.argsort()[-3:][::-1]
        chosen=[cs[i] for i in idx if scores[i]>.05]
        if chosen:return "Based on your material:\n\n"+"\\n\\n".join("• "+x for x in chosen)
    except: pass
    return "I could not find a close answer in the material."

def extract_file(file):
    name=file.filename.lower()
    data=file.read()
    if name.endswith(".txt"): return data.decode("utf-8","ignore")
    if name.endswith(".pdf"):
        try:
            from pypdf import PdfReader
            return "\n".join((p.extract_text() or "") for p in PdfReader(io.BytesIO(data)).pages)
        except Exception as e: raise ValueError("PDF reading failed. Please install pypdf.")
    if name.endswith(".docx"):
        try:
            from docx import Document
            return "\n".join(p.text for p in Document(io.BytesIO(data)).paragraphs)
        except Exception: raise ValueError("DOCX reading failed. Please install python-docx.")
    raise ValueError("Only PDF, DOCX and TXT are supported.")

@app.route("/")
def home(): return redirect("/dashboard") if "uid" in session else render_template("login.html")

@app.route("/register",methods=["GET","POST"])
def register():
    if request.method=="GET": return render_template("register.html")
    d=request.get_json(silent=True) or request.form
    name=(d.get("name") or "").strip(); email=(d.get("email") or "").strip(); pw=d.get("password") or ""
    if not name or not email or not pw:return jsonify(error="All fields are required"),400
    c=con()
    try:
        c.execute("INSERT INTO users(name,email,password) VALUES(?,?,?)",(name,email,generate_password_hash(pw)));c.commit()
    except sqlite3.IntegrityError:c.close();return jsonify(error="Email already registered"),400
    c.close();return jsonify(ok=True)

@app.route("/login",methods=["POST"])
def login():
    d=request.get_json(silent=True) or request.form
    c=con();u=c.execute("SELECT * FROM users WHERE email=?",(d.get("email",""),)).fetchone();c.close()
    if u and check_password_hash(u["password"],d.get("password","")):
        session["uid"]=u["id"];session["name"]=u["name"];return jsonify(ok=True)
    return jsonify(error="Invalid login"),401

@app.route("/logout")
def logout(): session.clear(); return redirect("/")

@app.route("/dashboard")
def dashboard():
    if "uid" not in session:return redirect("/")
    return render_template("dashboard.html",name=session["name"])

@app.route("/api/analyze",methods=["POST"])
def api_analyze():
    if "uid" not in session:return jsonify(error="Login required"),401
    d=request.get_json(silent=True) or {}; t=(d.get("content") or "").strip()
    if len(t)<30:return jsonify(error="Enter at least 30 characters"),400
    r=analyze(t); c=con()
    c.execute("INSERT INTO materials(user_id,subject,filename,content,summary,keywords) VALUES(?,?,?,?,?,?)",
              (session["uid"],d.get("subject") or "General",d.get("filename") or "Pasted Material",t," ".join(r["summary"]),",".join(x["term"] for x in r["keywords"])))
    c.commit();c.close();log("Smart Summary",d.get("subject") or "General","Generated");return jsonify(r)

@app.route("/api/upload",methods=["POST"])
def upload():
    if "uid" not in session:return jsonify(error="Login required"),401
    f=request.files.get("file")
    if not f:return jsonify(error="Choose a PDF or DOCX file"),400
    try:t=extract_file(f)
    except Exception as e:return jsonify(error=str(e)),400
    if len(t.strip())<30:return jsonify(error="The uploaded file contains less than 30 readable characters"),400
    r=analyze(t); subject=request.form.get("subject") or "Uploaded Material"
    c=con();c.execute("INSERT INTO materials(user_id,subject,filename,content,summary,keywords) VALUES(?,?,?,?,?,?)",
                      (session["uid"],subject,f.filename,t," ".join(r["summary"]),",".join(x["term"] for x in r["keywords"])))
    c.commit();mid=c.execute("SELECT last_insert_rowid()").fetchone()[0];c.close()
    log("Upload",subject,f.filename)
    return jsonify(id=mid,filename=f.filename,content=t,**r)

@app.route("/api/download/<kind>/<int:mid>")
def download(kind,mid):
    if "uid" not in session:return jsonify(error="Login required"),401
    c=con();m=c.execute("SELECT * FROM materials WHERE id=? AND user_id=?",(mid,session["uid"])).fetchone();c.close()
    if not m:return jsonify(error="Material not found"),404
    title=m["subject"] or "StudyMate"
    if kind=="txt":
        return send_file(io.BytesIO((m["content"]).encode()),as_attachment=True,download_name=title.replace(" ","_")+".txt",mimetype="text/plain")
    if kind=="docx":
        from docx import Document
        from docx.shared import Pt
        doc=Document();doc.add_heading(title,0);doc.add_paragraph("StudyMate NLP Study Material")
        doc.add_heading("Summary",1);doc.add_paragraph(m["summary"])
        doc.add_heading("Keywords",1);doc.add_paragraph(m["keywords"])
        doc.add_heading("Original Material",1);doc.add_paragraph(m["content"])
        b=io.BytesIO();doc.save(b);b.seek(0)
        return send_file(b,as_attachment=True,download_name=title.replace(" ","_")+".docx",mimetype="application/vnd.openxmlformats-officedocument.wordprocessingml.document")
    if kind=="pdf":
        from reportlab.platypus import SimpleDocTemplate,Paragraph,Spacer
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.lib.pagesizes import A4
        from reportlab.lib.units import mm
        b=io.BytesIO();doc=SimpleDocTemplate(b,pagesize=A4,rightMargin=18*mm,leftMargin=18*mm,topMargin=18*mm,bottomMargin=18*mm)
        st=getSampleStyleSheet();story=[Paragraph(title,st["Title"]),Spacer(1,8),Paragraph("StudyMate NLP Study Material",st["Normal"]),Spacer(1,8),Paragraph("Summary",st["Heading2"]),Paragraph(m["summary"].replace("&","&amp;"),st["BodyText"]),Spacer(1,8),Paragraph("Keywords",st["Heading2"]),Paragraph(m["keywords"].replace("&","&amp;"),st["BodyText"]),Spacer(1,8),Paragraph("Original Material",st["Heading2"])]
        for p in m["content"].splitlines():
            if p.strip():story.append(Paragraph(p.replace("&","&amp;"),st["BodyText"]));story.append(Spacer(1,3))
        doc.build(story);b.seek(0)
        return send_file(b,as_attachment=True,download_name=title.replace(" ","_")+".pdf",mimetype="application/pdf")
    return jsonify(error="Invalid format"),400

@app.route("/api/mcqs",methods=["POST"])
def api_mcqs(): return jsonify(mcqs=mcqs(latest_text((request.get_json(silent=True) or {}).get("content","")),8))

@app.route("/api/questions",methods=["POST"])
def api_questions(): return jsonify(questions=questions((request.get_json(silent=True) or {}).get("content",""),10))

@app.route("/api/chat",methods=["POST"])
def api_chat():
    d=request.get_json(silent=True) or {};q=d.get("question","")
    if "uid" in session and q.strip(): log("AI Chat",q[:30],"Answered")
    return jsonify(answer=chat_answer(latest_text(d.get("content","")),q))


# Offline demo translation: no Google API, package, or internet required.
TRANSLATIONS = {
    "en": {
        "artificial intelligence": "Artificial Intelligence",
        "artificial intelligence is a branch of computer science.": "Artificial Intelligence is a branch of computer science.",
        "artificial intelligence is a branch of computer science": "Artificial Intelligence is a branch of computer science",
        "machine learning": "Machine Learning",
        "natural language processing": "Natural Language Processing",
        "computer science": "Computer Science",
        "study material": "Study Material",
        "the computer understands human language": "The computer understands human language",
    },
    "ta": {
        "artificial intelligence": "செயற்கை நுண்ணறிவு",
        "artificial intelligence is a branch of computer science.": "செயற்கை நுண்ணறிவு என்பது கணினி அறிவியலின் ஒரு கிளையாகும்.",
        "artificial intelligence is a branch of computer science": "செயற்கை நுண்ணறிவு என்பது கணினி அறிவியலின் ஒரு கிளையாகும்",
        "machine learning": "இயந்திர கற்றல்",
        "natural language processing": "இயற்கை மொழி செயலாக்கம்",
        "computer science": "கணினி அறிவியல்",
        "study material": "படிப்பு பொருள்",
        "the computer understands human language": "கணினி மனித மொழியைப் புரிந்துகொள்கிறது",
        "learn smarter with nlp-powered study tools.": "NLP அடிப்படையிலான படிப்பு கருவிகள் மூலம் சிறப்பாகக் கற்றுக்கொள்ளுங்கள்.",
        "what is artificial intelligence?": "செயற்கை நுண்ணறிவு என்றால் என்ன?",
        "what is natural language processing?": "இயற்கை மொழி செயலாக்கம் என்றால் என்ன?",
    },
    "hi": {
        "artificial intelligence": "कृत्रिम बुद्धिमत्ता",
        "artificial intelligence is a branch of computer science.": "कृत्रिम बुद्धिमत्ता कंप्यूटर विज्ञान की एक शाखा है।",
        "artificial intelligence is a branch of computer science": "कृत्रिम बुद्धिमत्ता कंप्यूटर विज्ञान की एक शाखा है",
        "machine learning": "मशीन लर्निंग",
        "natural language processing": "प्राकृतिक भाषा प्रसंस्करण",
        "computer science": "कंप्यूटर विज्ञान",
        "study material": "अध्ययन सामग्री",
        "what is artificial intelligence?": "कृत्रिम बुद्धिमत्ता क्या है?",
        "what is natural language processing?": "प्राकृतिक भाषा प्रसंस्करण क्या है?",
    }
}

def offline_translate(text, target):
    target = target if target in TRANSLATIONS else "ta"
    key = re.sub(r"\s+", " ", text.strip()).lower()
    direct = TRANSLATIONS[target].get(key)
    if direct: return direct
    # Word/phrase fallback for common study vocabulary. Preserve punctuation approximately.
    maps = TRANSLATIONS[target]
    out = text
    for src, dst in sorted(maps.items(), key=lambda x: len(x[0]), reverse=True):
        if len(src) < 2: continue
        out = re.sub(r"(?i)\b" + re.escape(src) + r"\b", dst, out)
    if out == text:
        return "Offline demo translation: " + text
    return out

@app.route("/api/translate",methods=["POST"])
def translate():
    if "uid" not in session:return jsonify(error="Login required"),401
    d=request.get_json(silent=True) or {}
    text=(d.get("text") or "").strip(); target=d.get("target") or "ta"
    if not text:return jsonify(error="Enter text to translate"),400
    log("Translate",text[:30],target)
    return jsonify(translated=offline_translate(text,target),target=target,mode="offline")

@app.route("/api/profile",methods=["GET","POST"])
def profile():
    if "uid" not in session:return jsonify(error="Login required"),401
    c=con()
    if request.method=="GET":
        u=c.execute("SELECT id,name,email FROM users WHERE id=?",(session["uid"],)).fetchone()
        c.close()
        return jsonify(user=dict(u)) if u else (jsonify(error="User not found"),404)
    d=request.get_json(silent=True) or {}
    name=(d.get("name") or "").strip()
    email=(d.get("email") or "").strip()
    if not name or not email:return jsonify(error="Name and email are required"),400
    try:
        c.execute("UPDATE users SET name=?,email=? WHERE id=?",(name,email,session["uid"]))
        c.commit()
        session["name"]=name
        return jsonify(ok=True,user={"name":name,"email":email})
    except sqlite3.IntegrityError:
        return jsonify(error="Email already registered"),400
    finally:
        c.close()

@app.route("/api/bookmarks",methods=["GET","POST"])
def bookmarks():
    if "uid" not in session:return jsonify(error="Login required"),401
    c=con()
    if request.method=="POST":
        d=request.get_json(silent=True) or {}; title=(d.get("title") or "Saved Note").strip(); content=(d.get("content") or "").strip()
        if not content:return jsonify(error="Content is required"),400
        c.execute("INSERT INTO bookmarks(user_id,title,content) VALUES(?,?,?)",(session["uid"],title,content));c.commit()
        c.close();return jsonify(ok=True)
    rows=c.execute("SELECT id,title,content,created_at FROM bookmarks WHERE user_id=? ORDER BY id DESC",(session["uid"],)).fetchall();c.close()
    return jsonify(items=[dict(x) for x in rows])

@app.route("/api/bookmarks/<int:bid>",methods=["DELETE"])
def delete_bookmark(bid):
    if "uid" not in session:return jsonify(error="Login required"),401
    c=con();c.execute("DELETE FROM bookmarks WHERE id=? AND user_id=?",(bid,session["uid"]));c.commit();c.close();return jsonify(ok=True)

@app.route("/api/history")
def history():
    if "uid" not in session:return jsonify(error="Login required"),401
    c=con();r=c.execute("SELECT id,subject,filename,summary,keywords,created_at FROM materials WHERE user_id=? ORDER BY id DESC",(session["uid"],)).fetchall();c.close()
    return jsonify(items=[dict(x) for x in r])

@app.route("/api/stats")
def stats():
    if "uid" not in session:return jsonify(error="Login required"),401
    c=con();u=session["uid"]
    m=c.execute("SELECT COUNT(*) n,COALESCE(SUM(LENGTH(content)-LENGTH(REPLACE(content,' ',''))+1),0) words FROM materials WHERE user_id=?",(u,)).fetchone()
    q=c.execute("SELECT COUNT(*) n,COALESCE(AVG(score*100.0/NULLIF(total,0)),0) avg,COALESCE(SUM(total),0) solved FROM scores WHERE user_id=?",(u,)).fetchone()
    sub=[{"subject":r[0],"avg":int(r[1] or 0)} for r in c.execute("SELECT subject,ROUND(AVG(score*100.0/NULLIF(total,0))) FROM scores WHERE user_id=? GROUP BY subject",(u,))]
    have={r[0]:r[1] for r in c.execute("SELECT date(created_at),COUNT(*) FROM activity WHERE user_id=? GROUP BY 1",(u,))}
    c.close()
    d=datetime.utcnow().date()
    week=[{"day":(d-timedelta(k)).strftime("%a"),"n":have.get(str(d-timedelta(k)),0)} for k in range(6,-1,-1)]
    e=d if str(d) in have else d-timedelta(1);st=0
    while str(e) in have: st+=1;e-=timedelta(1)
    return jsonify(materials=m["n"],words=m["words"],quiz_attempts=q["n"],average_score=round(q["avg"],1),solved=q["solved"],streak=st,
                   mastered=sum(1 for x in sub if x["avg"]>=80),subjects=sub,weak=[x["subject"] for x in sub if x["avg"]<70],week=week)

@app.route("/api/score",methods=["POST"])
def score():
    if "uid" not in session:return jsonify(error="Login required"),401
    d=request.get_json(silent=True) or {};sub=d.get("subject") or "General";sc=int(d.get("score",0));tot=int(d.get("total",0))
    c=con();c.execute("INSERT INTO scores(user_id,subject,score,total) VALUES(?,?,?,?)",(session["uid"],sub,sc,tot));c.commit();c.close()
    log("MCQ Quiz",sub,f"{round(sc*100/max(tot,1))}%");return jsonify(ok=True)

@app.route("/api/log",methods=["POST"])
def log_api():
    if "uid" not in session:return jsonify(error="Login required"),401
    d=request.get_json(silent=True) or {};log(d.get("kind","Activity"),d.get("topic","")[:40],d.get("detail",""));return jsonify(ok=True)

@app.route("/api/activity")
def activity():
    if "uid" not in session:return jsonify(error="Login required"),401
    c=con();r=c.execute("SELECT kind,topic,detail,created_at FROM activity WHERE user_id=? ORDER BY id DESC LIMIT 40",(session["uid"],)).fetchall();c.close()
    return jsonify(items=[dict(x) for x in r])

@app.route("/api/flashcards",methods=["POST"])
def flashcards():
    if "uid" not in session:return jsonify(error="Login required"),401
    t=latest_text((request.get_json(silent=True) or {}).get("content",""))
    if len(t.strip())<30:return jsonify(error="Analyze some material first"),400
    cards=[];used=set()
    for k in keywords(t,20):
        w=k["term"]
        s=next((x for x in sents(t) if re.search(r"\b"+re.escape(w)+r"\b",x,re.I) and x not in used),None)
        if s: used.add(s);cards.append({"q":"What is "+w+"?" if len(w)>3 else "Explain "+w,"a":s})
        if len(cards)>=8:break
    log("Flashcards","latest material",f"{len(cards)} cards");return jsonify(cards=cards)

if __name__=="__main__":
    init_db();app.run(debug=True)
